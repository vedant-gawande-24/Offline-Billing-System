import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Invoice, InvoiceStatus, LineItem } from '../types';
import { saveInvoice, getClients, getProducts, getSettings, getInvoices } from '../services/storageService';
import { Trash2, Plus, Save, Printer, Eye, Edit } from 'lucide-react';

export const InvoiceForm: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams(); // Get ID from URL if in edit mode
  
  const [isPreview, setIsPreview] = useState(false);
  
  // Data for Autocomplete
  const clients = getClients();
  const products = getProducts();
  const settings = getSettings();

  const [createdAt, setCreatedAt] = useState<number>(Date.now());

  const [invoiceData, setInvoiceData] = useState<Omit<Invoice, 'id' | 'createdAt'>>({
    invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
    date: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    clientName: '',
    clientEmail: '',
    clientAddress: '',
    items: [{ id: '1', description: 'Service Fee', quantity: 1, price: 0 }],
    notes: settings.paymentInstructions || 'Thank you for your business.',
    status: InvoiceStatus.DRAFT,
    paymentLink: ''
  });

  // Load existing invoice data if ID is present
  useEffect(() => {
    if (id) {
      const invoices = getInvoices();
      const foundInvoice = invoices.find(i => i.id === id);
      if (foundInvoice) {
        setInvoiceData({
          invoiceNumber: foundInvoice.invoiceNumber,
          date: foundInvoice.date,
          dueDate: foundInvoice.dueDate,
          clientName: foundInvoice.clientName,
          clientEmail: foundInvoice.clientEmail,
          clientAddress: foundInvoice.clientAddress,
          items: foundInvoice.items,
          notes: foundInvoice.notes,
          status: foundInvoice.status,
          paymentLink: foundInvoice.paymentLink
        });
        setCreatedAt(foundInvoice.createdAt);
      }
    }
  }, [id]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setInvoiceData(prev => ({ ...prev, [name]: value }));
    
    // Auto-fill client details
    if (name === 'clientName') {
      const client = clients.find(c => c.name === value);
      if (client) {
        setInvoiceData(prev => ({
          ...prev,
          clientName: client.name,
          clientEmail: client.email,
          clientAddress: client.address
        }));
      }
    }
  };

  const handleItemChange = (id: string, field: keyof LineItem, value: string | number) => {
    setInvoiceData(prev => ({
      ...prev,
      items: prev.items.map(item => {
        if (item.id !== id) return item;
        
        const updatedItem = { ...item, [field]: value };
        
        // Auto-fill product price
        if (field === 'description') {
           const product = products.find(p => p.name === value);
           if (product) updatedItem.price = product.price;
        }
        return updatedItem;
      })
    }));
  };

  const addItem = () => {
    setInvoiceData(prev => ({
      ...prev,
      items: [...prev.items, { id: Date.now().toString(), description: '', quantity: 1, price: 0 }]
    }));
  };

  const removeItem = (id: string) => {
    setInvoiceData(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== id)
    }));
  };

  const calculateSubtotal = () => invoiceData.items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
  const calculateTax = () => calculateSubtotal() * (settings.taxRate / 100);
  const calculateTotal = () => calculateSubtotal() + calculateTax();

  const generateId = () => {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  const handleSave = () => {
    const newInvoice: Invoice = {
      ...invoiceData,
      id: id || generateId(),
      createdAt: createdAt,
    };
    saveInvoice(newInvoice);
    navigate('/invoices');
  };

  const handlePrint = () => {
    setIsPreview(true);
    setTimeout(() => {
      window.print();
    }, 100);
  };

  return (
    <div className="p-8 max-w-5xl mx-auto h-full overflow-y-auto print:p-0 print:overflow-visible">
      {/* Header Actions */}
      <div className="flex justify-between items-center mb-8 no-print">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 dark:text-white">{id ? 'Edit Invoice' : 'New Invoice'}</h2>
          <p className="text-slate-500 dark:text-slate-400">{id ? 'Modify existing invoice details' : 'Create a new invoice manually'}</p>
        </div>
        <div className="flex space-x-3">
          <button 
             onClick={() => setIsPreview(!isPreview)}
             className="px-4 py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-lg flex items-center space-x-2 transition-colors font-medium">
             {isPreview ? <Edit size={18} /> : <Eye size={18} />}
             <span>{isPreview ? 'Edit Invoice' : 'Preview'}</span>
          </button>
          
          <button 
            onClick={handlePrint}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg flex items-center space-x-2 transition-colors font-medium">
            <Printer size={18} />
            <span>Print / PDF</span>
          </button>
          <button 
            onClick={handleSave}
            className="px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg flex items-center space-x-2 transition-colors shadow-sm font-medium">
            <Save size={18} />
            <span>Save Invoice</span>
          </button>
        </div>
      </div>

      {/* Main Invoice Card */}
      <div className={`bg-white dark:bg-slate-800 shadow-lg rounded-xl overflow-hidden print:shadow-none print:rounded-none transition-colors ${isPreview ? 'print-preview-mode' : ''}`}>
        
        <div className="p-8 print:p-0">
          {/* Header Section */}
          <div className="flex flex-col md:flex-row justify-between mb-10">
            <div className="mb-6 md:mb-0">
              <h1 className="text-4xl font-bold text-slate-800 dark:text-white tracking-tight">INVOICE</h1>
              <div className="mt-2 flex items-center space-x-2">
                <span className="text-slate-500 dark:text-slate-400 font-medium">#</span>
                {isPreview ? (
                  <span className="text-lg font-mono text-slate-800 dark:text-white">{invoiceData.invoiceNumber}</span>
                ) : (
                  <input 
                    type="text" 
                    name="invoiceNumber"
                    value={invoiceData.invoiceNumber}
                    onChange={handleInputChange}
                    className="bg-transparent border-b border-dashed border-slate-300 dark:border-slate-600 focus:border-primary-500 outline-none text-slate-700 dark:text-slate-200 font-mono w-40"
                  />
                )}
              </div>
            </div>
            <div className="text-right">
               {/* Logo */}
               <div className="w-16 h-16 bg-slate-100 dark:bg-slate-700 rounded-lg ml-auto mb-2 flex items-center justify-center text-slate-300 dark:text-slate-500 overflow-hidden">
                 {settings.logoUrl ? (
                   <img src={settings.logoUrl} alt="Logo" className="w-full h-full object-cover" />
                 ) : (
                   <img src="https://picsum.photos/64/64" alt="Logo" className="rounded-lg opacity-80" />
                 )}
               </div>
               <p className="font-bold text-slate-700 dark:text-slate-200">{settings.companyName}</p>
               <p className="text-slate-500 dark:text-slate-400 text-sm">{settings.companyEmail}</p>
            </div>
          </div>

          {/* Client & Dates Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Bill To</label>
              <div className="space-y-3">
                {isPreview ? (
                  <div className="text-slate-800 dark:text-slate-200">
                    <p className="font-bold text-lg">{invoiceData.clientName || 'Client Name'}</p>
                    {invoiceData.clientEmail && <p className="text-sm text-slate-500">{invoiceData.clientEmail}</p>}
                    <p className="whitespace-pre-wrap text-sm mt-1">{invoiceData.clientAddress}</p>
                  </div>
                ) : (
                  <>
                    <input 
                      type="text" 
                      name="clientName"
                      list="clients-list"
                      placeholder="Client Name"
                      value={invoiceData.clientName}
                      onChange={handleInputChange}
                      className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-primary-100 dark:focus:ring-primary-900 focus:border-primary-400 dark:text-white outline-none transition-all"
                    />
                    <datalist id="clients-list">
                      {clients.map(c => <option key={c.id} value={c.name} />)}
                    </datalist>
                    <input 
                      type="email" 
                      name="clientEmail"
                      placeholder="client@email.com"
                      value={invoiceData.clientEmail}
                      onChange={handleInputChange}
                      className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-primary-100 dark:focus:ring-primary-900 focus:border-primary-400 dark:text-white outline-none transition-all"
                    />
                    <textarea 
                      name="clientAddress"
                      placeholder="Client Address"
                      value={invoiceData.clientAddress}
                      onChange={handleInputChange}
                      rows={3}
                      className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-primary-100 dark:focus:ring-primary-900 focus:border-primary-400 dark:text-white outline-none transition-all resize-none"
                    />
                  </>
                )}
              </div>
            </div>
            <div className="flex flex-col md:items-end">
              <div className="w-full md:w-64 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Date</label>
                  {isPreview ? (
                     <p className="text-slate-800 dark:text-slate-200 font-medium">{invoiceData.date}</p>
                  ) : (
                    <input 
                      type="date" 
                      name="date"
                      value={invoiceData.date}
                      onChange={handleInputChange}
                      className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-sm focus:border-primary-500 dark:text-white outline-none"
                    />
                  )}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Due Date</label>
                   {isPreview ? (
                     <p className="text-slate-800 dark:text-slate-200 font-medium">{invoiceData.dueDate}</p>
                  ) : (
                    <input 
                      type="date" 
                      name="dueDate"
                      value={invoiceData.dueDate}
                      onChange={handleInputChange}
                      className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-sm focus:border-primary-500 dark:text-white outline-none"
                    />
                  )}
                </div>
                <div className="print:hidden">
                   <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Status</label>
                   {isPreview ? (
                     <span className={`px-2 py-1 rounded-full text-xs font-medium 
                        ${invoiceData.status === InvoiceStatus.PAID ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400' : 
                          invoiceData.status === InvoiceStatus.PENDING ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400' : 
                          'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                        {invoiceData.status}
                      </span>
                   ) : (
                     <select 
                      name="status"
                      value={invoiceData.status}
                      onChange={handleInputChange}
                      className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-sm focus:border-primary-500 dark:text-white outline-none"
                     >
                       {Object.values(InvoiceStatus).map(s => <option key={s} value={s}>{s}</option>)}
                     </select>
                   )}
                </div>
              </div>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="mb-8">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b-2 border-slate-100 dark:border-slate-700 text-slate-500 dark:text-slate-400 text-xs uppercase tracking-wider">
                  <th className="py-3 font-semibold w-1/2">Description</th>
                  <th className="py-3 font-semibold w-20 text-center">Qty</th>
                  <th className="py-3 font-semibold w-32 text-right">Price</th>
                  <th className="py-3 font-semibold w-32 text-right">Total</th>
                  {!isPreview && <th className="py-3 w-10 print:hidden"></th>}
                </tr>
              </thead>
              <tbody className="text-sm">
                {invoiceData.items.map((item) => (
                  <tr key={item.id} className="group border-b border-slate-50 dark:border-slate-700/50">
                    <td className="py-2 pr-4">
                      {isPreview ? (
                        <span className="text-slate-700 dark:text-slate-200 font-medium">{item.description}</span>
                      ) : (
                        <>
                          <input 
                            type="text" 
                            value={item.description}
                            list="products-list"
                            onChange={(e) => handleItemChange(item.id, 'description', e.target.value)}
                            placeholder="Item description"
                            className="w-full bg-transparent border-none focus:ring-0 p-0 placeholder-slate-300 dark:placeholder-slate-600 font-medium text-slate-700 dark:text-slate-200"
                          />
                          <datalist id="products-list">
                            {products.map(p => <option key={p.id} value={p.name} />)}
                          </datalist>
                        </>
                      )}
                    </td>
                    <td className="py-2 px-2 text-center">
                       {isPreview ? (
                          <span className="text-slate-600 dark:text-slate-300">{item.quantity}</span>
                       ) : (
                          <input 
                            type="number" 
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleItemChange(item.id, 'quantity', parseFloat(e.target.value))}
                            className="w-full bg-transparent border-none focus:ring-0 p-0 text-center text-slate-600 dark:text-slate-300"
                          />
                       )}
                    </td>
                    <td className="py-2 px-2 text-right">
                       {isPreview ? (
                          <span className="text-slate-600 dark:text-slate-300">{item.price.toFixed(2)}</span>
                       ) : (
                          <input 
                            type="number" 
                            min="0"
                            step="0.01"
                            value={item.price}
                            onChange={(e) => handleItemChange(item.id, 'price', parseFloat(e.target.value))}
                            className="w-full bg-transparent border-none focus:ring-0 p-0 text-right text-slate-600 dark:text-slate-300"
                          />
                       )}
                    </td>
                    <td className="py-2 pl-4 text-right font-semibold text-slate-800 dark:text-white">
                      {settings.currency}{(item.quantity * item.price).toFixed(2)}
                    </td>
                    {!isPreview && (
                      <td className="py-2 text-center print:hidden">
                        {invoiceData.items.length > 1 && (
                          <button 
                            onClick={() => removeItem(item.id)}
                            className="text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            
            {!isPreview && (
              <button 
                onClick={addItem}
                className="mt-4 flex items-center space-x-2 text-sm text-primary-600 dark:text-primary-400 font-medium hover:text-primary-700 dark:hover:text-primary-300 print:hidden"
              >
                <Plus size={16} />
                <span>Add Line Item</span>
              </button>
            )}
          </div>

          {/* Totals Section */}
          <div className="flex justify-end border-t border-slate-100 dark:border-slate-700 pt-6">
            <div className="w-full md:w-1/3 space-y-3">
              <div className="flex justify-between text-sm text-slate-500 dark:text-slate-400">
                <span>Subtotal</span>
                <span>{settings.currency}{calculateSubtotal().toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm text-slate-500 dark:text-slate-400">
                <span>Tax ({settings.taxRate}%)</span>
                <span>{settings.currency}{calculateTax().toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-lg font-bold text-slate-800 dark:text-white pt-3 border-t border-slate-100 dark:border-slate-700">
                <span>Total</span>
                <span>{settings.currency}{calculateTotal().toFixed(2)}</span>
              </div>
            </div>
          </div>
          
          {/* Notes & Payment Link */}
          <div className="mt-10 pt-6 border-t border-slate-100 dark:border-slate-700">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Payment Link / UPI</label>
            {isPreview ? (
               <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">{invoiceData.paymentLink}</p>
            ) : (
              <input 
                type="text" 
                name="paymentLink"
                placeholder="e.g. paypal.me/yourname or UPI ID"
                value={invoiceData.paymentLink || ''}
                onChange={handleInputChange}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-sm mb-4 print:border-none print:p-0"
              />
            )}
            
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Notes</label>
            {isPreview ? (
               <p className="text-sm text-slate-600 dark:text-slate-300 whitespace-pre-wrap">{invoiceData.notes}</p>
            ) : (
               <textarea 
                  name="notes"
                  value={invoiceData.notes}
                  onChange={handleInputChange}
                  rows={2}
                  className="w-full bg-transparent border-none p-0 text-sm text-slate-600 dark:text-slate-300 resize-none focus:ring-0"
                />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
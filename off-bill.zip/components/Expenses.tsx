import React, { useState } from 'react';
import { getExpenses, saveExpense, deleteExpense, getSettings } from '../services/storageService';
import { Expense } from '../types';
import { Plus, Trash2 } from 'lucide-react';

export const Expenses: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>(getExpenses());
  const [isAdding, setIsAdding] = useState(false);
  const [newExpense, setNewExpense] = useState<Omit<Expense, 'id'>>({ date: new Date().toISOString().split('T')[0], payee: '', category: '', amount: 0, notes: '' });
  const settings = getSettings();

  const handleSave = () => {
    if (!newExpense.payee || !newExpense.amount) return;
    saveExpense({ ...newExpense, id: Date.now().toString() });
    setExpenses(getExpenses());
    setNewExpense({ date: new Date().toISOString().split('T')[0], payee: '', category: '', amount: 0, notes: '' });
    setIsAdding(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete this expense?')) {
      deleteExpense(id);
      setExpenses(getExpenses());
    }
  };

  return (
    <div className="p-8 h-full overflow-y-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Expenses</h2>
        <button onClick={() => setIsAdding(true)} className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2">
          <Plus size={18} /> <span>Add Expense</span>
        </button>
      </div>

      {isAdding && (
        <div className="mb-8 bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
           <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold dark:text-white">New Expense</h3>
           </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="date" value={newExpense.date} onChange={e => setNewExpense({...newExpense, date: e.target.value})} className="p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
            <input type="text" placeholder="Payee / Vendor" value={newExpense.payee} onChange={e => setNewExpense({...newExpense, payee: e.target.value})} className="p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
            <input type="text" placeholder="Category (e.g. Travel, Office)" value={newExpense.category} onChange={e => setNewExpense({...newExpense, category: e.target.value})} className="p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
            <input type="number" placeholder="Amount" value={newExpense.amount} onChange={e => setNewExpense({...newExpense, amount: parseFloat(e.target.value)})} className="p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
            <textarea placeholder="Notes" value={newExpense.notes} onChange={e => setNewExpense({...newExpense, notes: e.target.value})} className="md:col-span-2 p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
          </div>
          <div className="mt-4 flex space-x-2">
            <button onClick={handleSave} className="px-4 py-2 bg-primary-600 text-white rounded hover:bg-primary-700">Save</button>
            <button onClick={() => setIsAdding(false)} className="px-4 py-2 bg-slate-200 text-slate-700 rounded hover:bg-slate-300 dark:bg-slate-700 dark:text-slate-200">Cancel</button>
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 dark:bg-slate-900 border-b border-slate-100 dark:border-slate-700">
            <tr>
              <th className="py-4 px-6 text-xs text-slate-500 uppercase">Date</th>
              <th className="py-4 px-6 text-xs text-slate-500 uppercase">Payee</th>
              <th className="py-4 px-6 text-xs text-slate-500 uppercase">Category</th>
              <th className="py-4 px-6 text-xs text-slate-500 uppercase text-right">Amount</th>
              <th className="py-4 px-6 text-xs text-slate-500 uppercase text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50 dark:divide-slate-700">
            {expenses.map(exp => (
              <tr key={exp.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                <td className="py-4 px-6 text-sm dark:text-slate-300">{exp.date}</td>
                <td className="py-4 px-6 font-medium dark:text-white">{exp.payee}</td>
                <td className="py-4 px-6"><span className="px-2 py-1 bg-slate-100 dark:bg-slate-700 rounded-full text-xs">{exp.category}</span></td>
                <td className="py-4 px-6 text-right font-semibold text-red-600 dark:text-red-400">-{settings.currency}{exp.amount.toFixed(2)}</td>
                <td className="py-4 px-6 text-right">
                   <button onClick={() => handleDelete(exp.id)} className="text-slate-400 hover:text-red-500"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
import React, { useState, useEffect } from 'react';
import { getSettings, saveSettings, getProducts, saveProduct, deleteProduct, exportData, importData } from '../services/storageService';
import { AppSettings, Product } from '../types';
import { Save, Download, Upload, Plus, Trash2 } from 'lucide-react';

export const Settings: React.FC = () => {
  const [settings, setSettings] = useState<AppSettings>(getSettings());
  const [products, setProducts] = useState<Product[]>(getProducts());
  const [newProduct, setNewProduct] = useState({ name: '', price: 0 });
  const [importStatus, setImportStatus] = useState('');

  const handleSettingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setSettings(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveSettings = () => {
    saveSettings(settings);
    alert('Settings saved!');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSettings(prev => ({ ...prev, logoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddProduct = () => {
    if (!newProduct.name) return;
    const product: Product = { ...newProduct, id: Date.now().toString() };
    saveProduct(product);
    setProducts(getProducts());
    setNewProduct({ name: '', price: 0 });
  };

  const handleDeleteProduct = (id: string) => {
    deleteProduct(id);
    setProducts(getProducts());
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const success = await importData(file);
      setImportStatus(success ? 'Import Successful! Please refresh.' : 'Import Failed.');
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8 pb-20 overflow-y-auto h-full">
      <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Settings</h2>

      {/* General Settings */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
        <h3 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">General Configuration</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-500 mb-1">Company Name</label>
            <input type="text" name="companyName" value={settings.companyName} onChange={handleSettingChange} className="w-full p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-500 mb-1">Company Email</label>
            <input type="email" name="companyEmail" value={settings.companyEmail} onChange={handleSettingChange} className="w-full p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-500 mb-1">Currency Symbol</label>
            <input type="text" name="currency" value={settings.currency} onChange={handleSettingChange} className="w-full p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-500 mb-1">Default Tax Rate (%)</label>
            <input type="number" name="taxRate" value={settings.taxRate} onChange={handleSettingChange} className="w-full p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-slate-500 mb-1">Payment Instructions</label>
            <textarea name="paymentInstructions" value={settings.paymentInstructions || ''} onChange={handleSettingChange} rows={3} className="w-full p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white" placeholder="Bank details, UPI ID, etc." />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-slate-500 mb-1">Logo</label>
            <div className="flex items-center space-x-4">
              {settings.logoUrl && <img src={settings.logoUrl} alt="Logo" className="h-16 w-16 object-contain border rounded" />}
              <input type="file" accept="image/*" onChange={handleLogoUpload} className="text-sm text-slate-500" />
            </div>
          </div>
        </div>
        <button onClick={handleSaveSettings} className="mt-6 px-4 py-2 bg-primary-600 text-white rounded flex items-center space-x-2 hover:bg-primary-700">
          <Save size={18} /> <span>Save Changes</span>
        </button>
      </div>

      {/* Product Catalog */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
        <h3 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">Product & Service Catalog</h3>
        <div className="flex space-x-2 mb-4">
          <input 
            type="text" 
            placeholder="Item Name" 
            value={newProduct.name}
            onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
            className="flex-1 p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white"
          />
          <input 
            type="number" 
            placeholder="Price" 
            value={newProduct.price}
            onChange={(e) => setNewProduct({ ...newProduct, price: parseFloat(e.target.value) })}
            className="w-32 p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white"
          />
          <button onClick={handleAddProduct} className="px-4 bg-primary-600 text-white rounded hover:bg-primary-700"><Plus size={20} /></button>
        </div>
        <ul className="divide-y divide-slate-100 dark:divide-slate-700">
          {products.map(p => (
            <li key={p.id} className="py-2 flex justify-between items-center">
              <div>
                <span className="font-medium text-slate-800 dark:text-white">{p.name}</span>
                <span className="ml-2 text-slate-500 dark:text-slate-400">{settings.currency}{p.price}</span>
              </div>
              <button onClick={() => handleDeleteProduct(p.id)} className="text-red-500 hover:text-red-700"><Trash2 size={16} /></button>
            </li>
          ))}
          {products.length === 0 && <li className="text-slate-400 italic">No products saved.</li>}
        </ul>
      </div>

      {/* Data Management */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
        <h3 className="text-xl font-semibold mb-4 text-slate-800 dark:text-white">Data Management</h3>
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
          <button onClick={exportData} className="px-4 py-2 border border-slate-300 dark:border-slate-600 rounded flex items-center justify-center space-x-2 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-white">
            <Download size={18} /> <span>Backup Data (JSON)</span>
          </button>
          <label className="px-4 py-2 border border-slate-300 dark:border-slate-600 rounded flex items-center justify-center space-x-2 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-white cursor-pointer">
            <Upload size={18} /> <span>Restore Data</span>
            <input type="file" accept=".json" onChange={handleImport} className="hidden" />
          </label>
        </div>
        {importStatus && <p className="mt-2 text-sm font-medium text-emerald-600">{importStatus}</p>}
      </div>
    </div>
  );
};
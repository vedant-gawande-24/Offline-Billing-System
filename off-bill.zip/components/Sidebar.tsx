import React from 'react';
import { LayoutDashboard, FileText, PlusCircle, WifiOff, Sun, Moon, Users, Receipt, Settings as SettingsIcon } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

interface SidebarProps {
  isOnline: boolean;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOnline, theme, toggleTheme }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path 
    ? "bg-primary-600 text-white shadow-md" 
    : "text-slate-300 hover:bg-slate-800 hover:text-white";

  return (
    <div className="w-64 bg-slate-900 text-white flex flex-col h-full no-print border-r border-slate-800">
      <div className="p-6">
        <h1 className="text-2xl font-bold tracking-tight text-primary-500">OFF Bill</h1>
        <p className="text-xs text-slate-500 mt-1 uppercase tracking-wider">Offline Billing</p>
      </div>

      <nav className="flex-1 px-4 space-y-2 overflow-y-auto">
        <Link to="/" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${isActive('/')}`}>
          <LayoutDashboard size={20} />
          <span className="font-medium">Dashboard</span>
        </Link>
        <Link to="/invoices" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${isActive('/invoices')}`}>
          <FileText size={20} />
          <span className="font-medium">Invoices</span>
        </Link>
        <Link to="/create" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${isActive('/create')}`}>
          <PlusCircle size={20} />
          <span className="font-medium">New Invoice</span>
        </Link>
        <Link to="/expenses" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${isActive('/expenses')}`}>
          <Receipt size={20} />
          <span className="font-medium">Expenses</span>
        </Link>
        <Link to="/clients" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${isActive('/clients')}`}>
          <Users size={20} />
          <span className="font-medium">Clients</span>
        </Link>
        <Link to="/settings" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${isActive('/settings')}`}>
          <SettingsIcon size={20} />
          <span className="font-medium">Settings</span>
        </Link>
      </nav>

      <div className="p-6 border-t border-slate-800 space-y-4">
        {/* Theme Toggle */}
        <button 
          onClick={toggleTheme}
          className="flex items-center justify-between w-full px-4 py-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors text-sm"
        >
          <div className="flex items-center space-x-2">
            {theme === 'dark' ? <Moon size={16} /> : <Sun size={16} />}
            <span>{theme === 'dark' ? 'Dark Mode' : 'Light Mode'}</span>
          </div>
        </button>

        <div>
          <div className="flex items-center space-x-2 text-sm text-amber-400">
            <WifiOff size={16} />
            <span>Offline</span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Data stored locally.
          </p>
        </div>
      </div>
    </div>
  );
};
import React, { useEffect, useState } from 'react';
import { 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area 
} from 'recharts';
import { getDashboardStats, getInvoices, getSettings } from '../services/storageService';
import { IndianRupee, FileClock, TrendingUp, Plus, Search, TrendingDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { InvoiceStatus, Invoice } from '../types';

export const Dashboard: React.FC = () => {
  const [stats, setStats] = useState(getDashboardStats());
  const [invoices, setInvoices] = useState<Invoice[]>(getInvoices());
  const [filteredInvoices, setFilteredInvoices] = useState<Invoice[]>([]);
  const settings = getSettings();
  
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    setStats(getDashboardStats());
    const allInvoices = getInvoices();
    setInvoices(allInvoices);
    setFilteredInvoices(allInvoices.slice(0, 5));
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery) {
        setFilteredInvoices(invoices.slice(0, 5));
        return;
    }
    
    // Simple filter by name or invoice number
    setFilteredInvoices(invoices.filter(i => 
      i.clientName.toLowerCase().includes(searchQuery.toLowerCase()) || 
      i.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase())
    ));
  };

  const chartData = [
    { name: 'Jan', revenue: stats.totalRevenue * 0.1 },
    { name: 'Feb', revenue: stats.totalRevenue * 0.2 },
    { name: 'Mar', revenue: stats.totalRevenue * 0.15 },
    { name: 'Apr', revenue: stats.totalRevenue * 0.3 },
    { name: 'May', revenue: stats.totalRevenue * 0.25 },
  ];

  return (
    <div className="p-8 space-y-8 animate-fade-in overflow-y-auto h-full text-slate-900 dark:text-slate-100">
      <div className="flex flex-col md:flex-row justify-between md:items-center space-y-4 md:space-y-0">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Dashboard</h2>
          <p className="text-slate-500 dark:text-slate-400">Financial Overview & Insights</p>
        </div>
        
        {/* Search Bar */}
        <form onSubmit={handleSearch} className="relative w-full md:w-96">
            <input 
                type="text" 
                placeholder="Search invoices by client or number..." 
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-primary-500 outline-none transition-all shadow-sm"
            />
            <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
        </form>

        <Link to="/create" className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors shadow-sm">
          <Plus size={18} />
          <span>Create Invoice</span>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 flex items-center space-x-4 transition-colors">
          <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg">
            <IndianRupee size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Net Profit</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-white">{settings.currency}{stats.netProfit.toFixed(2)}</p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 flex items-center space-x-4 transition-colors">
          <div className="p-3 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">
            <TrendingUp size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Revenue</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-white">{settings.currency}{stats.totalRevenue.toFixed(2)}</p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 flex items-center space-x-4 transition-colors">
          <div className="p-3 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg">
            <TrendingDown size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Expenses</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-white">{settings.currency}{stats.totalExpenses.toFixed(2)}</p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 flex items-center space-x-4 transition-colors">
          <div className="p-3 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg">
            <FileClock size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Pending</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-white">{settings.currency}{stats.pendingAmount.toFixed(2)}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 h-80 transition-colors">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-4 flex items-center">
            <TrendingUp size={18} className="mr-2 text-slate-400" />
            Revenue Trend
          </h3>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" strokeOpacity={0.2} />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8'}} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8'}} />
              <Tooltip 
                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', backgroundColor: 'var(--tw-prose-invert-body)' }}
                itemStyle={{ color: '#3b82f6' }}
                formatter={(value: number) => [`${settings.currency}${value.toFixed(2)}`, 'Revenue']}
              />
              <Area type="monotone" dataKey="revenue" stroke="#3b82f6" fillOpacity={1} fill="url(#colorRevenue)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 transition-colors">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-4">
             {searchQuery ? "Search Results" : "Recent Invoices"}
          </h3>
          <div className="space-y-3">
            {filteredInvoices.length === 0 && (
              <p className="text-slate-400 text-center py-10 italic">No invoices found.</p>
            )}
            {filteredInvoices.map((inv) => (
              <div key={inv.id} className="flex items-center justify-between p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 rounded-lg border border-slate-100 dark:border-slate-700 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${inv.status === InvoiceStatus.PAID ? 'bg-emerald-500' : inv.status === InvoiceStatus.PENDING ? 'bg-amber-500' : 'bg-slate-400'}`} />
                  <div>
                    <p className="font-medium text-slate-700 dark:text-slate-200">{inv.clientName}</p>
                    <p className="text-xs text-slate-400">#{inv.invoiceNumber}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-slate-800 dark:text-slate-100">
                    {settings.currency}{inv.items.reduce((sum, i) => sum + (i.price * i.quantity), 0).toFixed(2)}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{inv.date}</p>
                </div>
              </div>
            ))}
          </div>
          {!searchQuery && (
            <div className="mt-4 text-center">
              <Link to="/invoices" className="text-primary-600 dark:text-primary-400 text-sm font-medium hover:text-primary-700 dark:hover:text-primary-300">View All Invoices</Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
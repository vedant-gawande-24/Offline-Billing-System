import React, { useState } from 'react';
import { getClients, saveClient, deleteClient } from '../services/storageService';
import { Client } from '../types';
import { Plus, Trash2, User } from 'lucide-react';

export const Clients: React.FC = () => {
  const [clients, setClients] = useState<Client[]>(getClients());
  const [isAdding, setIsAdding] = useState(false);
  const [newClient, setNewClient] = useState<Omit<Client, 'id'>>({ name: '', email: '', address: '' });

  const handleSave = () => {
    if (!newClient.name) return;
    saveClient({ ...newClient, id: Date.now().toString() });
    setClients(getClients());
    setNewClient({ name: '', email: '', address: '' });
    setIsAdding(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete this client?')) {
      deleteClient(id);
      setClients(getClients());
    }
  };

  return (
    <div className="p-8 h-full overflow-y-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Clients</h2>
        <button onClick={() => setIsAdding(true)} className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2">
          <Plus size={18} /> <span>Add Client</span>
        </button>
      </div>

      {isAdding && (
        <div className="mb-8 bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input 
              type="text" placeholder="Name" className="p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white"
              value={newClient.name} onChange={e => setNewClient({...newClient, name: e.target.value})}
            />
            <input 
              type="email" placeholder="Email" className="p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white"
              value={newClient.email} onChange={e => setNewClient({...newClient, email: e.target.value})}
            />
            <textarea 
              placeholder="Address" className="md:col-span-2 p-2 border rounded dark:bg-slate-900 dark:border-slate-700 dark:text-white"
              value={newClient.address} onChange={e => setNewClient({...newClient, address: e.target.value})}
            />
          </div>
          <div className="mt-4 flex space-x-2">
            <button onClick={handleSave} className="px-4 py-2 bg-primary-600 text-white rounded hover:bg-primary-700">Save</button>
            <button onClick={() => setIsAdding(false)} className="px-4 py-2 bg-slate-200 text-slate-700 rounded hover:bg-slate-300 dark:bg-slate-700 dark:text-slate-200">Cancel</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {clients.map(client => (
          <div key={client.id} className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 relative group">
            <div className="flex items-center space-x-3 mb-3">
              <div className="bg-primary-100 dark:bg-primary-900/30 p-2 rounded-full text-primary-600 dark:text-primary-400">
                <User size={20} />
              </div>
              <h3 className="font-bold text-slate-800 dark:text-white">{client.name}</h3>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">{client.email}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400 whitespace-pre-wrap">{client.address}</p>
            <button onClick={() => handleDelete(client.id)} className="absolute top-4 right-4 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
              <Trash2 size={18} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
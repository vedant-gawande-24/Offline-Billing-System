export enum InvoiceStatus {
  DRAFT = 'Draft',
  PENDING = 'Pending',
  PAID = 'Paid',
}

export interface LineItem {
  id: string;
  description: string;
  quantity: number;
  price: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  clientName: string;
  clientEmail: string;
  clientAddress: string;
  items: LineItem[];
  notes: string;
  status: InvoiceStatus;
  createdAt: number;
  paymentLink?: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  address: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
}

export interface Expense {
  id: string;
  date: string;
  payee: string;
  category: string;
  amount: number;
  notes: string;
  receiptImage?: string;
}

export interface AppSettings {
  companyName: string;
  companyEmail: string;
  currency: string;
  taxRate: number;
  logoUrl?: string;
  paymentInstructions?: string;
}

export interface DashboardStats {
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  pendingAmount: number;
  paidInvoicesCount: number;
  totalInvoicesCount: number;
}
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { InvoiceForm } from './components/InvoiceForm';
import { Clients } from './components/Clients';
import { Expenses } from './components/Expenses';
import { Settings } from './components/Settings';
import { getInvoices, deleteInvoice, getSettings } from './services/storageService';
import { InvoiceStatus } from './types';
import { Trash2, Pencil } from 'lucide-react';

const InvoiceList: React.FC = () => {
  const [invoices, setInvoices] = useState(getInvoices());
  const settings = getSettings();

  // Refresh invoices when the component mounts or when navigating back
  useEffect(() => {
    setInvoices(getInvoices());
  }, []);

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this invoice?')) {
      deleteInvoice(id);
      setInvoices(prev => prev.filter(inv => inv.id !== id));
    }
  };

  return (
    <div className="p-8 h-full overflow-y-auto">
      <h2 className="text-3xl font-bold text-slate-800 dark:text-white mb-6">My Invoices</h2>
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden transition-colors">
        {invoices.length === 0 ? (
          <div className="p-10 text-center text-slate-500 dark:text-slate-400">
            No invoices found. Create your first one!
          </div>
        ) : (
          <table className="w-full text-left">
            <thead className="bg-slate-50 dark:bg-slate-900 border-b border-slate-100 dark:border-slate-700">
              <tr>
                <th className="py-4 px-6 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">Number</th>
                <th className="py-4 px-6 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">Client</th>
                <th className="py-4 px-6 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">Date</th>
                <th className="py-4 px-6 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">Status</th>
                <th className="py-4 px-6 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase text-right">Amount</th>
                <th className="py-4 px-6 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 dark:divide-slate-700">
              {invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors group">
                  <td className="py-4 px-6 font-mono text-sm text-slate-600 dark:text-slate-300">#{inv.invoiceNumber}</td>
                  <td className="py-4 px-6 font-medium text-slate-800 dark:text-slate-200">{inv.clientName}</td>
                  <td className="py-4 px-6 text-sm text-slate-500 dark:text-slate-400">{inv.date}</td>
                  <td className="py-4 px-6">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium 
                      ${inv.status === InvoiceStatus.PAID ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400' : 
                        inv.status === InvoiceStatus.PENDING ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400' : 
                        'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right font-semibold text-slate-700 dark:text-slate-200">
                    {settings.currency}{inv.items.reduce((s, i) => s + (i.price * i.quantity), 0).toFixed(2)}
                  </td>
                  <td className="py-4 px-6 text-right">
                    <div className="flex justify-end space-x-2">
                      <Link 
                        to={`/edit/${inv.id}`}
                        className="p-1.5 text-slate-400 hover:text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/30 rounded-md transition-colors"
                        title="Edit Invoice"
                      >
                        <Pencil size={18} />
                      </Link>
                      <button 
                        onClick={() => handleDelete(inv.id)} 
                        className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-md transition-colors"
                        title="Delete Invoice"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      return 'dark';
    } else {
      return 'light';
    }
  });

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  return (
    <Router>
      <div className="flex h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-200">
        <Sidebar isOnline={isOnline} theme={theme} toggleTheme={toggleTheme} />
        <main className="flex-1 overflow-hidden relative">
           {!isOnline && (
            <div className="absolute top-0 left-0 right-0 bg-amber-500 text-white text-xs text-center py-1 z-50 print:hidden opacity-90">
              Offline Mode Active. Data will be saved locally.
            </div>
           )}
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/invoices" element={<InvoiceList />} />
            <Route path="/create" element={<InvoiceForm />} />
            <Route path="/edit/:id" element={<InvoiceForm />} />
            <Route path="/clients" element={<Clients />} />
            <Route path="/expenses" element={<Expenses />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;

const CACHE_NAME = 'billflow-v1';

// Install event: Skip waiting to activate immediately
self.addEventListener('install', () => {
  self.skipWaiting();
});

// Activate event: Claim clients to control them immediately
self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Fetch event: Stale-while-revalidate strategy
self.addEventListener('fetch', (event) => {
  // Only cache GET requests
  if (event.request.method !== 'GET') return;
  
  // Skip caching for non-http/https (e.g., chrome-extension://)
  if (!event.request.url.startsWith('http')) return;

  event.respondWith(
    caches.open(CACHE_NAME).then(async (cache) => {
      // Try to get from cache
      const cachedResponse = await cache.match(event.request);
      
      // Fetch from network to update cache (background)
      const fetchPromise = fetch(event.request).then((networkResponse) => {
        // Check if response is valid
        if (networkResponse && networkResponse.status === 200 && (networkResponse.type === 'basic' || networkResponse.type === 'cors')) {
           // Clone and cache
           cache.put(event.request, networkResponse.clone());
        }
        return networkResponse;
      }).catch(() => {
        // Network failed, nothing to do here if we have cachedResponse
      });

      // Return cached response if available, otherwise wait for network
      return cachedResponse || fetchPromise;
    })
  );
});
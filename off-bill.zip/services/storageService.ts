import { Invoice, InvoiceStatus, Client, Product, Expense, AppSettings } from '../types';

const INVOICES_KEY = 'billflow_invoices_v1';
const CLIENTS_KEY = 'billflow_clients_v1';
const PRODUCTS_KEY = 'billflow_products_v1';
const EXPENSES_KEY = 'billflow_expenses_v1';
const SETTINGS_KEY = 'billflow_settings_v1';

// --- Generic Helpers ---
const getItem = <T>(key: string, defaultValue: T): T => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultValue;
  } catch (e) {
    console.error(`Failed to load ${key}`, e);
    return defaultValue;
  }
};

const setItem = <T>(key: string, data: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error(`Failed to save ${key}`, e);
    // Simple alert for quota exceeded
    if (e instanceof DOMException && e.name === 'QuotaExceededError') {
      alert("Storage quota exceeded. Please delete old data or remove large images.");
    }
  }
};

// --- Invoices ---
export const getInvoices = (): Invoice[] => getItem(INVOICES_KEY, []);
export const saveInvoice = (invoice: Invoice): void => {
  const list = getInvoices();
  const index = list.findIndex((i) => i.id === invoice.id);
  if (index >= 0) list[index] = invoice;
  else list.unshift(invoice);
  setItem(INVOICES_KEY, list);
};
export const deleteInvoice = (id: string): void => {
  setItem(INVOICES_KEY, getInvoices().filter((i) => i.id !== id));
};

// --- Clients ---
export const getClients = (): Client[] => getItem(CLIENTS_KEY, []);
export const saveClient = (client: Client): void => {
  const list = getClients();
  const index = list.findIndex((c) => c.id === client.id);
  if (index >= 0) list[index] = client;
  else list.push(client);
  setItem(CLIENTS_KEY, list);
};
export const deleteClient = (id: string): void => {
  setItem(CLIENTS_KEY, getClients().filter((c) => c.id !== id));
};

// --- Products ---
export const getProducts = (): Product[] => getItem(PRODUCTS_KEY, []);
export const saveProduct = (product: Product): void => {
  const list = getProducts();
  const index = list.findIndex((p) => p.id === product.id);
  if (index >= 0) list[index] = product;
  else list.push(product);
  setItem(PRODUCTS_KEY, list);
};
export const deleteProduct = (id: string): void => {
  setItem(PRODUCTS_KEY, getProducts().filter((p) => p.id !== id));
};

// --- Expenses ---
export const getExpenses = (): Expense[] => getItem(EXPENSES_KEY, []);
export const saveExpense = (expense: Expense): void => {
  const list = getExpenses();
  const index = list.findIndex((e) => e.id === expense.id);
  if (index >= 0) list[index] = expense;
  else list.unshift(expense);
  setItem(EXPENSES_KEY, list);
};
export const deleteExpense = (id: string): void => {
  setItem(EXPENSES_KEY, getExpenses().filter((e) => e.id !== id));
};

// --- Settings ---
const defaultSettings: AppSettings = {
  companyName: 'Indroyd Labs',
  companyEmail: 'IndroydLabs@gmail.com',
  currency: '₹',
  taxRate: 0,
};
export const getSettings = (): AppSettings => getItem(SETTINGS_KEY, defaultSettings);
export const saveSettings = (settings: AppSettings): void => setItem(SETTINGS_KEY, settings);

// --- Dashboard Stats ---
export const getDashboardStats = () => {
  const invoices = getInvoices();
  const expenses = getExpenses();

  const totalRevenue = invoices
    .filter(i => i.status === InvoiceStatus.PAID)
    .reduce((sum, inv) => sum + inv.items.reduce((s, item) => s + (item.price * item.quantity), 0), 0);
  
  const pendingAmount = invoices
    .filter(i => i.status === InvoiceStatus.PENDING)
    .reduce((sum, inv) => sum + inv.items.reduce((s, item) => s + (item.price * item.quantity), 0), 0);

  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);

  return {
    totalRevenue,
    totalExpenses,
    netProfit: totalRevenue - totalExpenses,
    pendingAmount,
    paidInvoicesCount: invoices.filter(i => i.status === InvoiceStatus.PAID).length,
    totalInvoicesCount: invoices.length
  };
};

// --- Backup & Restore ---
export const exportData = () => {
  const data = {
    invoices: getInvoices(),
    clients: getClients(),
    products: getProducts(),
    expenses: getExpenses(),
    settings: getSettings(),
    timestamp: Date.now()
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `offbill_backup_${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

export const importData = async (file: File): Promise<boolean> => {
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    
    if (data.invoices) setItem(INVOICES_KEY, data.invoices);
    if (data.clients) setItem(CLIENTS_KEY, data.clients);
    if (data.products) setItem(PRODUCTS_KEY, data.products);
    if (data.expenses) setItem(EXPENSES_KEY, data.expenses);
    if (data.settings) setItem(SETTINGS_KEY, data.settings);
    
    return true;
  } catch (e) {
    console.error("Import failed", e);
    return false;
  }
};
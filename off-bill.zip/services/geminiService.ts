// AI Features removed.
export const extractInvoiceData = async (imageBase64: string, mimeType: string) => {
  return null;
};

export const generateInvoiceEmail = async (invoice: any, companyName: string) => {
  return null;
};

export const parseSearchQuery = async (query: string) => {
  return null;
};